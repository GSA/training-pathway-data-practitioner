# Change Log
All notable changes to this project will be documented in this file.

## [0.0.1] - 2016-09-13
### Changed
- dimple.min.js source was changed, and the plugin now supports https protocol

## [0.0.2] - 2016-11-23
### Added
- D3Mekko now supports exporting to PDF.

## [0.0.3] - 2018-01-02
### Added
- Visualization supports the filter selection on mobile devices.

## [0.0.4] - 2018-01-04
### Fixed
- Fixing currency values so they can be displayed and animated.